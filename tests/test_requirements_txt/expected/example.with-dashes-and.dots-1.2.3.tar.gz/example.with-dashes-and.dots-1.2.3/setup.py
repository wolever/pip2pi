from distutils.core import setup

setup(
    name="example.with-dashes-and.dots",
    version="1.2.3",
    py_modules=["example_with_dashes_and_dots"],
)
