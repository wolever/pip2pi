from distutils.core import setup

setup(name="Normalization_Test.with-dashes", version="1.2rc3")
